//
//  BCOVPluginManager.h
//  ios-videocloud
//
//  Created by Erik Price on 2013 08 08.
//  Copyright (c) 2013 Brightcove. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@protocol BCOVPlaybackFacade;


extern NSString * const BCOVStringsVisibleVersionIdentification;


@interface BCOVVideoCloudManager : NSObject

/**
 * Creates and returns a new fully-configured playback facade object.
 *
 * @param frame The desired frame for the facade's video view.
 * @return A new playback facade instance.
 */
- (id<BCOVPlaybackFacade>)newPlaybackFacadeWithFrame:(CGRect)frame;

/**
 * Returns the Video Cloud manager singleton.
 *
 * @return The Video Cloud manager singleton.
 */
+ (BCOVVideoCloudManager *)sharedManager;

@end
