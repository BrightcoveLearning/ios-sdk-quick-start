//
//  SVPViewController.m
//  Simple Video Playback
//
//  Created by Robert Crooks on 9/30/13.
//  Copyright (c) 2013 Brightcove. All rights reserved.
//

#import "SVPViewController.h"

#import "BCOVPlaybackSession.h"
#import "BCOVPlaybackController.h"
#import "BCOVPlaybackFacade.h"
#import "BCOVVideoCloudManager.h"

#import "BCOVVideo.h"

@interface SVPViewController ()

@end

@implementation SVPViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	NSArray *videos = @[
                        //[BCOVVideo videoWithURL:[NSURL URLWithString:@"http://cf9c36303a9981e3e8cc-31a5eb2af178214dc2ca6ce50f208bb5.r97.cf1.rackcdn.com/bigger_badminton_600.mp4"]],
                        [BCOVVideo videoWithURL:[NSURL URLWithString:@"http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8"]]
                        ];
    
    self.manager = [BCOVVideoCloudManager sharedManager];
    self.facade = [self.manager newPlaybackFacadeWithFrame:self.view.frame];
    
    [self.view addSubview:self.facade.view];
    
    [self.facade setVideos:videos];
    [self.facade advanceToNext];
    [self.facade play];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
