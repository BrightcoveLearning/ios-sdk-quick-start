//
//  BCOVPlaybackQueue.h
//  ios-videocloud
//
//  Created by Erik Price on 2013 09 26.
//  Copyright (c) 2013 Brightcove. All rights reserved.
//

#import <Foundation/Foundation.h>


@class RACSignal;


@protocol BCOVPlaybackQueue <NSObject>

/**
 * Whether to advance to the next playback session when its previous playback
 * session sends kBCOVPlaybackSessionLifecycleEventEnd. If this event is sent
 * more than once by a playback session, the subsequent sends are ignored.
 *
 * Defaults to NO.
 *
 * @return True if this queue should send the next session when the previous
 * session sends kBCOVPlaybackSessionLifecycleEventEnd.
 */
@property (nonatomic, assign, getter = isAutoAdvance) BOOL autoAdvance;

/**
 * Instructs this instance to advance the queue, dequeueing a new playback
 * session. The session will be delivered via the `playbackSessions` signal.
 * This may occur asynchronously, so you must use the signal in order to take
 * action once the session is dequeued.
 */
- (void)advanceToNext;

/**
 * Specifies the source from which this instance will draw its upcoming videos
 * for playback. Note that setting a new source will not automatically send
 * a new playback session on `playbackSessions`; use `-advanceToNext` to send
 * a playback session for the first video in the source.
 *
 * The source is enumerated immediately upon being set and each video element
 * is defensively copied into this queue.
 *
 * @param videos The source of BCOVVideo objects from which this instance
 * should construct a queue for playback. This value is enumerated immediately
 * and its elements are copied.
 */
- (void)setVideos:(id<NSFastEnumeration>)videos;

/**
 * Returns a signal of playback sessions created by this instance.
 *
 * @return A signal of this instance's playback sessions.
 */
- (RACSignal *)playbackSessions;

@end
