//
//  BCOVCuePointCollection.h
//  ios-videocloud
//
//  Created by Erik Price on 2013 09 13.
//  Copyright (c) 2013 Brightcove. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>


@class BCOVCuePoint;


/**
 * A collection of cue points, each element ordered by its position according
 * to the natural ordering of CMTime values.
 */
@interface BCOVCuePointCollection : NSObject <NSCopying, NSFastEnumeration>

/**
 * Constructs and returns a BCOVCuePointCollection from the cue points in the
 * specified unordered array. The returned collection will be ordered according
 * to the positions of the cue points. The ordering of multiple cue points with
 * the same position is not guaranteed.
 */
- (id)initWithArray:(NSArray *)cuePoints;
- (id)initWithCuePoint:(BCOVCuePoint *)cuePoint;
- (NSArray *)array;
- (NSUInteger)count;
- (instancetype)cuePointsAfterTime:(CMTime)time;
- (instancetype)cuePointsBeforeTime:(CMTime)time;
- (instancetype)cuePointsAtTime:(CMTime)time;
- (instancetype)cuePointsAtOrAfterTime:(CMTime)time;
- (instancetype)cuePointsAtOrBeforeTime:(CMTime)time;
- (instancetype)cuePointsAfterTime:(CMTime)lowerBound beforeTime:(CMTime)upperBound;
- (instancetype)cuePointsAfterTime:(CMTime)lowerBound atOrBeforeTime:(CMTime)upperBound;
- (instancetype)cuePointsAtOrAfterTime:(CMTime)lowerBound beforeTime:(CMTime)upperBound;
- (instancetype)cuePointsAtOrAfterTime:(CMTime)lowerBound atOrBeforeTime:(CMTime)upperBound;
- (BOOL)isEqualToCollection:(BCOVCuePointCollection *)collection;

/**
 * Returns the cue point at the specified index, or nil if the specified index
 * is greater than the highest index into the collection.
 *
 * @param index The index into this collection of the desired cue point.
 * @return The cue point at the specified index, or nil if this collection
 * does not have a cue point at that index.
 */
- (BCOVCuePoint *)objectAtIndexedSubscript:(NSUInteger)index;

+ (instancetype)collectionWithArray:(NSArray *)cuePoints;
+ (instancetype)emptyCollection;

@end