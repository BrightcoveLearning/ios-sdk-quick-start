//
//  SVPViewController.m
//  Simple Video Playback
//
//  Created by Robert Crooks on 9/30/13.
//  Copyright (c) 2013 Brightcove. All rights reserved.
//

// import the View Controller header
#import "SVPViewController.h"

// import the required SDK headers
#import "BCOVPlaybackSession.h"
#import "BCOVPlaybackController.h"
#import "BCOVPlaybackFacade.h"
#import "BCOVVideoCloudManager.h"
#import "BCOVPlaybackQueue.h"

#import "BCOVVideo.h"

@interface SVPViewController ()

@end

@implementation SVPViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// create an array of videos
    NSArray *videos = @[
                        [BCOVVideo videoWithURL:[NSURL URLWithString:@"http://cf9c36303a9981e3e8cc-31a5eb2af178214dc2ca6ce50f208bb5.r97.cf1.rackcdn.com/bigger_badminton_600.mp4"]],
                        [BCOVVideo videoWithURL:[NSURL URLWithString:@"http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8"]]
                        ];
    
    // add a video manager and facade
    self.manager = [BCOVVideoCloudManager sharedManager];
    self.facade = [self.manager newPlaybackFacadeWithFrame:self.view.frame];
    
    // turn on auto-advance
    self.facade.queue.autoAdvance = YES;
    
    // add the facade view as an app subview
    [self.view addSubview:self.facade.view];
    
    // add the video array to the playback session and play the first one
    [self.facade setVideos:videos];
    [self.facade advanceToNextAndPlay];
}

@end
