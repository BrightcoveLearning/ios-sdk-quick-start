//
//  SVPAppDelegate.h
//  Simple Video Playback
//
//  Created by Robert Crooks on 9/30/13.
//  Copyright (c) 2013 Brightcove. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SVPAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
