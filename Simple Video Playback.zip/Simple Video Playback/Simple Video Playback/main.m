//
//  main.m
//  Simple Video Playback
//
//  Created by Robert Crooks on 9/30/13.
//  Copyright (c) 2013 Brightcove. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SVPAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SVPAppDelegate class]));
    }
}
