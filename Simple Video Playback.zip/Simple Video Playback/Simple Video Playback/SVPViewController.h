//
//  SVPViewController.h
//  Simple Video Playback
//
//  Created by Robert Crooks on 9/30/13.
//  Copyright (c) 2013 Brightcove. All rights reserved.
//

#import <UIKit/UIKit.h>
// import the facade header
#import "BCOVPlaybackFacade.h"

// forward references for facade and video cloud manager classes
@class BCOVPlaybackFacade;
@class BCOVVideoCloudManager;

@interface SVPViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIView *view;

@property (strong, nonatomic) id<BCOVPlaybackFacade> facade;
@property (strong, nonatomic) BCOVVideoCloudManager *manager;

@end
